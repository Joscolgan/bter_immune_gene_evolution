library(rjson)
suppressMessages(library(tidyverse))

analysis_dir <- "~/Documents/PhD/analyses/bombus-selection-analysis/"
setwd(analysis_dir)


# Load additional data ------------------------------------------------------------------------

orthogroups <- read_tsv("data/N1.tsv")
bt_protein2gene <- read_tsv("data/bt_gene2protein.tsv", col_names = c("geneID", "proteinID"))
bt_gene2gene_descr <- read_tsv("data/bt_gene2gene_description.tsv", col_names = c("geneID", "geneDescription"))
bt_immune_orthogroups <- read.table("data/b_terrestris_immune_sc_orthogroups.txt")[[1]]
missing_orthogroups <- c("OG0003843", "OG0005599")
sc_orthogroups <- read.table("data/sc_orthogroups.txt")[[1]]
sc_orthogroups <- sc_orthogroups[! sc_orthogroups %in% missing_orthogroups]



# Gather aBSREL results -----------------------------------------------------------------------

hyphy_res_orthogroups <- vector()
for (orthogroup in sc_orthogroups){
   if(file.exists(paste0("data/from_mogon/hyphy_absrel/", orthogroup,
                         ".faa_nuc.fas.aligned.msa.json"))){
      hyphy_res_orthogroups <- append(hyphy_res_orthogroups, orthogroup)
   }
}

n <- length(hyphy_res_orthogroups)
progress_bar <- txtProgressBar(min = 0, max = n, style = 3, char = "=")
bt_absrel_selection_stats <- tribble(~orthogroup, ~pval, ~bhAdjPval,
                                     ~dnds1, ~dnds1Proportion,
                                     ~dnds2, ~dnds2Proportion,
                                     ~dnds3, ~dnds3Proportion)
for(i in 1:n){
   file <- rjson::fromJSON(
      file = paste0("data/from_mogon/hyphy_absrel/", hyphy_res_orthogroups[[i]], 
                    ".faa_nuc.fas.aligned.msa.json"), simplify = TRUE)
   bt_branch <- which(grepl("Bombus_terrestris", 
                            names(file$`branch attributes`$`0`)))
   if (length(bt_branch) == 0){
      setTxtProgressBar(progress_bar, i)
   } else {
      uncorrected_pval <- file[["branch attributes"]][["0"]][[bt_branch]][["Uncorrected P-value"]]
      corrected_pval <- file[["branch attributes"]][["0"]][[bt_branch]][["Corrected P-value"]]
      n_rate_classes <- file[["branch attributes"]][["0"]][[bt_branch]][["Rate classes"]]
      dnds <- c(NA, NA, NA)
      dnds_proportion <- c(NA, NA, NA)
      for(j in 1:n_rate_classes){
         dnds[j] <- file[["branch attributes"]][["0"]][[bt_branch]][["Rate Distributions"]][[j]][1]
         dnds_proportion[j] <- 
            file[["branch attributes"]][["0"]][[bt_branch]][["Rate Distributions"]][[j]][2]
      }
      bt_absrel_selection_stats <- add_row(
         bt_absrel_selection_stats, orthogroup = hyphy_res_orthogroups[[i]],
         pval = uncorrected_pval, bhAdjPval = corrected_pval,
         dnds1 = dnds[1], dnds1Proportion = dnds_proportion[1],
         dnds2 = dnds[2], dnds2Proportion = dnds_proportion[2],
         dnds3 = dnds[3], dnds3Proportion = dnds_proportion[3])
      setTxtProgressBar(progress_bar, i)
   }
}


# Gather BUSTED results -----------------------------------------------------------------------

hyphy_res_orthogroups <- vector()
for (orthogroup in sc_orthogroups){
   if(file.exists(paste0("data/from_lab_pc/hyphy_busted/", orthogroup,
                         ".faa_nuc.fas.aligned.msa.json"))){
      hyphy_res_orthogroups <- append(hyphy_res_orthogroups, orthogroup)
   }
}

n <- length(hyphy_res_orthogroups)
progress_bar <- txtProgressBar(min = 0, max = n, style = 3, char = "=")
bt_busted_selection_stats <- tribble(~orthogroup, ~pval,
                                     ~dnds1, ~dnds1Proportion,
                                     ~dnds2, ~dnds2Proportion,
                                     ~dnds3, ~dnds3Proportion)

for(i in 1:n){
   file <- rjson::fromJSON(
      file = paste0("data/from_lab_pc/hyphy_busted/", hyphy_res_orthogroups[[i]], 
                    ".faa_nuc.fas.aligned.msa.json"), simplify = TRUE)
   pval <- file[["test results"]][["p-value"]]
   dnds <- c(NA, NA, NA)
   dnds_proportion <- c(NA, NA, NA)
   for (j in 1:3){
      dnds[j] <- file[["fits"]][["Unconstrained model"]][["Rate Distributions"]][["Test"]][[j]][[1]]
      dnds_proportion[j] <- 
         file[["fits"]][["Unconstrained model"]][["Rate Distributions"]][["Test"]][[j]][[2]]
   }
   bt_busted_selection_stats <- add_row(
      bt_busted_selection_stats, orthogroup = hyphy_res_orthogroups[[i]],
      pval = pval,
      dnds1 = dnds[1], dnds1Proportion = dnds_proportion[1],
      dnds2 = dnds[2], dnds2Proportion = dnds_proportion[2],
      dnds3 = dnds[3], dnds3Proportion = dnds_proportion[3])
   setTxtProgressBar(progress_bar, i)
   
}


# Gather BUSTED CONSERVED results -------------------------------------------------------------

hyphy_res_orthogroups <- vector()
for (orthogroup in sc_orthogroups){
   if(file.exists(paste0("data/from_lab_pc/hyphy_busted_conserved/", orthogroup,
                         ".faa_nuc.fas.aligned.msa.json"))){
      hyphy_res_orthogroups <- append(hyphy_res_orthogroups, orthogroup)
   }
}

n <- length(hyphy_res_orthogroups)
progress_bar <- txtProgressBar(min = 0, max = n, style = 3, char = "=")
bt_bustedc_selection_stats <- tribble(~orthogroup, ~pval,
                                     ~dnds1, ~dnds1Proportion,
                                     ~dnds2, ~dnds2Proportion,
                                     ~dnds3, ~dnds3Proportion)

for(i in 1:n){
   file <- rjson::fromJSON(
      file = paste0("data/from_lab_pc/hyphy_busted_conserved/", hyphy_res_orthogroups[[i]], 
                    ".faa_nuc.fas.aligned.msa.json"), simplify = TRUE)
   pval <- file[["test results"]][["p-value"]]
   dnds <- c(NA, NA, NA)
   dnds_proportion <- c(NA, NA, NA)
   for (j in 1:3){
      dnds[j] <- file[["fits"]][["Unconstrained model"]][["Rate Distributions"]][["Test"]][[j]][[1]]
      dnds_proportion[j] <- 
         file[["fits"]][["Unconstrained model"]][["Rate Distributions"]][["Test"]][[j]][[2]]
   }
   bt_bustedc_selection_stats <- add_row(
      bt_bustedc_selection_stats, orthogroup = hyphy_res_orthogroups[[i]],
      pval = pval,
      dnds1 = dnds[1], dnds1Proportion = dnds_proportion[1],
      dnds2 = dnds[2], dnds2Proportion = dnds_proportion[2],
      dnds3 = dnds[3], dnds3Proportion = dnds_proportion[3])
   setTxtProgressBar(progress_bar, i)
   
}

# Combine data and write out ------------------------------------------------------------------

bt_absrel_selection_stats_annotated <- orthogroups %>% dplyr::select(OG, Bombus_terrestris) %>% 
   dplyr::distinct() %>% filter(!is.na(Bombus_terrestris)) %>% 
   dplyr::rename(proteinID = Bombus_terrestris, orthogroup = OG) %>% 
   left_join(bt_protein2gene) %>% left_join(bt_gene2gene_descr) %>% 
   right_join(bt_absrel_selection_stats) %>% dplyr::distinct(geneID, .keep_all = TRUE)

bt_busted_selection_stats_annotated <- orthogroups %>% dplyr::select(OG, Bombus_terrestris) %>% 
   dplyr::distinct() %>% filter(!is.na(Bombus_terrestris)) %>% 
   dplyr::rename(proteinID = Bombus_terrestris, orthogroup = OG) %>% 
   left_join(bt_protein2gene) %>% left_join(bt_gene2gene_descr) %>% 
   right_join(bt_busted_selection_stats) %>% dplyr::distinct(geneID, .keep_all = TRUE)

bt_bustedc_selection_stats_annotated <- orthogroups %>% dplyr::select(OG, Bombus_terrestris) %>% 
   dplyr::distinct() %>% filter(!is.na(Bombus_terrestris)) %>% 
   dplyr::rename(proteinID = Bombus_terrestris, orthogroup = OG) %>% 
   left_join(bt_protein2gene) %>% left_join(bt_gene2gene_descr) %>% 
   right_join(bt_bustedc_selection_stats) %>% dplyr::distinct(geneID, .keep_all = TRUE)


write_tsv(bt_busted_selection_stats_annotated, "results/bt_busted_selection.tsv")
write_tsv(bt_bustedc_selection_stats_annotated, "results/bt_busted_conserved_selection.tsv")
write_tsv(bt_absrel_selection_stats_annotated, "results/bt_absrel_selection.tsv")
write_tsv(bt_absrel_selection_stats_annotated %>% dplyr::filter(orthogroup %in% bt_immune_orthogroups),
          "results/bt_absrel_selection_immune_genes.tsv")