suppressMessages(library(tidyverse))

analysis_dir <- "~/Documents/PhD/analyses/bombus-selection-analysis/"
setwd(analysis_dir)

missing_orthogroups <- c("OG0003843", "OG0005599")
sc_orthogroups <- read.table("data/sc_orthogroups.txt")[[1]]
sc_orthogroups <- sc_orthogroups[! sc_orthogroups %in% missing_orthogroups]
n <- length(sc_orthogroups)
#n <- 100
progress_bar <- txtProgressBar(min = 0, max = n, style = 3, char = "=")
ob_ol_seq_sims <- vector()

for(i in 1:n){
   suppressMessages( seq_sim_df <- read_csv(
      file = paste0("data/from_lab_pc/sequence_similarity/", sc_orthogroups[i], 
                    ".faa_protein.fas_aligned.msa"), show_col_types = FALSE,
      num_threads = 1, col_names = TRUE) %>% dplyr::select(-1) )
   ob_id <- which(colnames(seq_sim_df) == "Osmia_bicornis")
   ol_id <- which(colnames(seq_sim_df) == "Osmia_lignaria")
   ob_ol_seq_sims[[sc_orthogroups[i]]] <- seq_sim_df[[ob_id]][[ol_id]]
   setTxtProgressBar(progress_bar, i)
}
ob_ol_seq_sims <- 1 - ob_ol_seq_sims
ob_ol_seq_sim_tbl <- tibble(
   orthogroup = names(ob_ol_seq_sims), seq_similarity = ob_ol_seq_sims)
write_tsv(ob_ol_seq_sim_tbl, "results/ob_ol_seq_similarity.tsv")